import pandas as pd
import random

# === Load Dataset ===
print("🔄 Loading dataset...")
try:
    df = pd.read_csv("Phishing_Email.csv")  # Universal path: same folder
except FileNotFoundError:
    print("❌ File not found. Make sure 'Phishing_Email.csv' is in the same folder.")
    exit()

# === Sample 1000 Emails ===
df_sample = df.sample(n=1000, random_state=42)

# === Detection Function ===
def Detect_Email_Threat(email_text):
    visual_semantic_features = {
        "has_logo": True,
        "layout_anomaly": random.choice([True, False])
    }

    feature_vector = {
        "text_length": len(str(email_text)),
        "has_link": "http" in str(email_text),
        "user_behavior_score": random.uniform(0, 1),
        "global_threat_score": random.uniform(0, 1),
        "impersonation_risk": random.choice(["Low", "High"]),
        "robustness": random.choice([True, False])
    }

    if feature_vector["global_threat_score"] > 0.85:
        return "Confirmed Threat: Block/Quarantine"
    elif feature_vector["user_behavior_score"] > 0.7 and not feature_vector["robustness"]:
        return "High Suspicion: User Alert & Sandboxing"
    elif feature_vector["impersonation_risk"] == "High":
        return "Impersonation Risk: Quarantine & Identity Verification"
    elif feature_vector["user_behavior_score"] > 0.7:
        return "Moderate Suspicion: User Alert & Further Analysis"
    elif not feature_vector["robustness"]:
        return "Potential Evasion: Flag for Review"
    else:
        return "Legitimate: Deliver"

# === Run Detection ===
print("🚀 Running threat detection on 1000 samples...")
results = df_sample.apply(lambda row: Detect_Email_Threat(row.get("EmailText", "")), axis=1)

# === Summarize Results ===
summary = results.value_counts()
print("\n📊 Detection Summary:")
print(summary)
